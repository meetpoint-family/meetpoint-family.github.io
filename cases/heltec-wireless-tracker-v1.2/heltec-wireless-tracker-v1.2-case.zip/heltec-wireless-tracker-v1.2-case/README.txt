Case for the Heltec Wireless Tracker V1.2 (no battery)
======================================================
Free to print, change and share (CC BY 4.0). From NeedToApp, the maker of MeetPoint and Arke.

Files
- heltec_tracker_v1_2_base.stl   the base
- heltec_tracker_v1_2_lid.stl    plain lid with a snap fit
- heltec_case.py                 the parametric model (makes the STL files)
- images/                        views of the case

Outside: 81.6 x 32.5 x 17.4 mm

Printing
- PETG (best if it will sit in the sun) or PLA, 0.2 mm layers, no supports.
- Base: floor down on the bed. Lid: flat face down on the bed, lip up.

Assembly
1. Lay the board in the base with the USB-C against the wall at the USB end.
2. Fit a panel-mount SMA connector in the hole at the other end (8 mm nut on the inside).
3. Press the lid on until it clicks. To open it, use the notch on one long side.

Adjusting (at the top of heltec_case.py)
- SNAP_R     snap fit: 0.5 if it is too stiff, 0.7 if the lid comes off by itself
- ANT_SPACE  room for the antenna adapter (12 mm; 15 mm for a thick cable)
- usb_z      height of the USB-C, if it doesn't line up with the opening
- board_h    board height, to make the case lower after measuring your board
- LCD_WINDOW, BUTTON_PINS, LED_HOLE: True for a screen window, button pins, a hole for the charge LED

Positions were measured from a photo (about ±0.5 mm): print the base first and check the fit.

To make the files again:  pip install manifold3d trimesh  &&  python3 heltec_case.py
